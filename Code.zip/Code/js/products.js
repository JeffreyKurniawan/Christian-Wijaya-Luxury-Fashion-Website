document.addEventListener("DOMContentLoaded", () => {
    const categoryFilter = document.getElementById("category-filter")
    const sortFilter = document.getElementById("sort-filter")
    const productCards = document.querySelectorAll(".product-card")
  
    if (categoryFilter && sortFilter) {
      categoryFilter.addEventListener("change", () => {
        filterProducts()
      })
      sortFilter.addEventListener("change", () => {
        sortProducts()
      })
  
      function filterProducts() {
        const selectedCategory = categoryFilter.value
  
        productCards.forEach((card) => {
          if (selectedCategory === "all" || card.dataset.category === selectedCategory) {
            card.style.display = "block"
          } else {
            card.style.display = "none"
          }
        })
        sortProducts()
      }
  
      function sortProducts() {
        const selectedSort = sortFilter.value
        const productsGrid = document.querySelector(".products-grid")
        const visibleProducts = Array.from(productCards).filter((card) => card.style.display !== "none")
        switch (selectedSort) {
          case "price-high":
            visibleProducts.sort((a, b) => {
              const priceA = Number.parseFloat(
                a.querySelector(".product-price").textContent.replace("Rp", "").replace(".", ""),
              )
              const priceB = Number.parseFloat(
                b.querySelector(".product-price").textContent.replace("Rp", "").replace(".", ""),
              )
              return priceB - priceA
            })
            break
          case "price-low":
            visibleProducts.sort((a, b) => {
              const priceA = Number.parseFloat(
                a.querySelector(".product-price").textContent.replace("Rp", "").replace(".", ""),
              )
              const priceB = Number.parseFloat(
                b.querySelector(".product-price").textContent.replace("Rp", "").replace(".", ""),
              )
              return priceA - priceB
            })
            break
          case "newest":
            visibleProducts.reverse()
            break
          default:
            break
        }
        visibleProducts.forEach((product) => {
          productsGrid.appendChild(product)
        })
      }
    }
  })
  