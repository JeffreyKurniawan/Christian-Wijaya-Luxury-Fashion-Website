document.addEventListener("DOMContentLoaded", () => {

    const registrationForm = document.getElementById("model-registration-form")
    const formResponse = document.getElementById("form-response")
  
    if (registrationForm) {
      registrationForm.addEventListener("submit", (e) => {
        e.preventDefault()
        const errorMessages = document.querySelectorAll(".error-message")
        errorMessages.forEach((message) => {
          message.textContent = ""
        })
        let isValid = true
        const fullName = document.getElementById("full-name").value.trim()
        const fullNameError = document.getElementById("full-name-error")
  
        if (fullName === "") {
          fullNameError.textContent = "Full name is required"
          isValid = false
        } else if (fullName.split(" ").filter((word) => word.length > 0).length < 2) {
          fullNameError.textContent = "Please enter your full name (first and last name)"
          isValid = false
        }
 
        const email = document.getElementById("email").value.trim()
        const emailError = document.getElementById("email-error")
  
        if (email === "") {
          emailError.textContent = "Email address is required"
          isValid = false
        } else if (!validateEmail(email)) {
          emailError.textContent = "Please enter a valid email address"
          isValid = false
        }
  
        const birthDate = document.getElementById("birth-date").value
        const birthDateError = document.getElementById("birth-date-error")
  
        if (birthDate === "") {
          birthDateError.textContent = "Date of birth is required"
          isValid = false
        } else {
          const today = new Date()
          const birthDateObj = new Date(birthDate)
          let age = today.getFullYear() - birthDateObj.getFullYear()
          const monthDiff = today.getMonth() - birthDateObj.getMonth()
  
          if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDateObj.getDate())) {
            age--
          }
  
          if (age < 16) {
            birthDateError.textContent = "You must be at least 16 years old to apply"
            isValid = false
          }
        }
  
        const phone = document.getElementById("phone").value.trim()
        const phoneError = document.getElementById("phone-error")
  
        if (phone === "") {
          phoneError.textContent = "Phone number is required"
          isValid = false
        } else if (!validatePhone(phone)) {
          phoneError.textContent = "Please enter a valid phone number (numbers only)"
          isValid = false
        }
  
        const terms = document.getElementById("terms").checked
        const termsError = document.getElementById("terms-error")
  
        if (!terms) {
          termsError.textContent = "You must agree to the terms and conditions"
          isValid = false
        }

        if (isValid) {
          formResponse.textContent =
            "Thank you for your application! We will review your information and contact you soon."
          formResponse.className = "form-response success"
          registrationForm.reset()
  
          formResponse.scrollIntoView({ behavior: "smooth" })
        }
      })
    }
  
    function validateEmail(email) {
      if (!email.includes("@")) return false
  
      const parts = email.split("@")
      if (parts.length !== 2) return false
  
      const [localPart, domain] = parts
      if (localPart.length === 0 || domain.length === 0) return false
  
      if (!domain.includes(".")) return false
  
      const domainParts = domain.split(".")
      if (domainParts[domainParts.length - 1].length < 2) return false
  
      return true
    }
  
    function validatePhone(phone) {
      for (let i = 0; i < phone.length; i++) {
        const char = phone.charAt(i)
        if (char < "0" || char > "9") {
          if (i === 0 && char === "+") {
            continue
          }
          if (char === " " || char === "-") {
            continue
          }
          return false
        }
      }
      return true
    }
  })
  