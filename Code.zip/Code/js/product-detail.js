document.addEventListener("DOMContentLoaded", () => {
    const mainImage = document.getElementById("main-product-image")
    const thumbnails = document.querySelectorAll(".thumbnail")
  
    if (mainImage && thumbnails.length > 0) {
      thumbnails.forEach((thumbnail) => {
        thumbnail.addEventListener("click", function () {
          mainImage.src = this.dataset.image

          thumbnails.forEach((thumb) => thumb.classList.remove("active"))
          this.classList.add("active")
        })
      })
    }
  
    const quantityInput = document.getElementById("quantity")
    const decreaseBtn = document.getElementById("decrease-quantity")
    const increaseBtn = document.getElementById("increase-quantity")
  
    if (quantityInput && decreaseBtn && increaseBtn) {
      decreaseBtn.addEventListener("click", () => {
        const currentValue = Number.parseInt(quantityInput.value)
        if (currentValue > 1) {
          quantityInput.value = currentValue - 1
        }
      })
  
      increaseBtn.addEventListener("click", () => {
        const currentValue = Number.parseInt(quantityInput.value)
        if (currentValue < 10) {
          quantityInput.value = currentValue + 1
        }
      })
      quantityInput.addEventListener("change", function () {
        const value = Number.parseInt(this.value)
        if (isNaN(value) || value < 1) {
          this.value = 1
        } else if (value > 10) {
          this.value = 10
        }
      })
    }
  
    const addToCartBtn = document.getElementById("add-to-cart")
  
    if (addToCartBtn) {
      addToCartBtn.addEventListener("click", () => {
        const productTitle = document.querySelector(".product-title").textContent
        const quantity = document.getElementById("quantity").value
        const size = document.getElementById("size-select").value
        const color = document.getElementById("color-select").value
        alert(`Added to Cart: ${quantity} ${color} ${productTitle} (Size: ${size.toUpperCase()})`)
      })
    }
  
    const orderNowBtn = document.getElementById("order-now")
  
    if (orderNowBtn) {
      orderNowBtn.addEventListener("click", () => {
        const productTitle = document.querySelector(".product-title").textContent
        const quantity = document.getElementById("quantity").value
        const size = document.getElementById("size-select").value
        const color = document.getElementById("color-select").value
        alert(`Proceeding to Checkout: ${quantity} ${color} ${productTitle} (Size: ${size.toUpperCase()})`)
      })
    }
  })
  