document.addEventListener("DOMContentLoaded", () => {
    const menuToggle = document.querySelector(".menu-toggle")
    const navMenu = document.querySelector(".nav-menu")
  
    if (menuToggle) {
      menuToggle.addEventListener("click", () => {
        navMenu.classList.toggle("active")
      })
    }

    const newsletterForm = document.getElementById("newsletter-form")
    const newsletterMessage = document.getElementById("newsletter-message")
  
    if (newsletterForm) {
      newsletterForm.addEventListener("submit", (e) => {
        e.preventDefault()
  
        const email = document.getElementById("newsletter-email").value
        if (!validateEmail(email)) {
          newsletterMessage.textContent = "Please enter a valid email address."
          newsletterMessage.style.color = "#e74c3c"
          return
        }
  
        newsletterMessage.textContent = "Thank you for subscribing to our newsletter!"
        newsletterMessage.style.color = "#2ecc71"
        newsletterForm.reset()
      })
    }

    const header = document.querySelector("header")
  
    window.addEventListener("scroll", () => {
      if (window.scrollY > 50) {
        header.style.padding = "0.5rem 1rem"
        header.style.boxShadow = "0 2px 10px rgba(0, 0, 0, 0.1)"
      } else {
        header.style.padding = "1rem 1rem"
        header.style.boxShadow = "0 2px 10px rgba(0, 0, 0, 0.05)"
      }
    })
  
    function validateEmail(email) {
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      return re.test(email)
    }
  })
  